##############
INICIO
##############

Crear usuario:
    http://127.0.0.1:5000/registro/<nombre>_<contrasenia>_<correo>_<fecha_nacimiento>

Detalles del usuario:
    http://127.0.0.1:5000/detalles/<nombre>/<usuario>_<contrasenia> 

    No me ha dado tiempo ha terminar la validacion pero independientemente de lo que 
    se ponga muestra un usuario de prueba.