from flask import Flask
from datetime import datetime

application = Flask(__name__)
error = 0
persona = {
    "nombre":"",
    "contrasenia":"",
    "correo":"",
    "fecha_nacimiento":""
}

@application.route('/registro/<nombre>_<contrasenia>_<correo>_<fecha_nacimiento>')
def registrar_persona(nombre, contrasenia, correo, fecha_nacimiento):
    # Primera comprobacion de errores para mostrarlos
    posible_error = "<h2>El formato es NOMBRE_CONTRASEÑA_CORREO_FEHCA NACIMIENTO</h2>"
    posible_error += comprobar_contrasenia(contrasenia)
    posible_error += comprobar_correo(correo)
    posible_error += comprobar_fecha(fecha_nacimiento)

    # Comprobar que todos los campos están bien
    if(comprobar_contrasenia(contrasenia) == "" and comprobar_correo(correo) == "" and comprobar_fecha(fecha_nacimiento) == ""):
        persona["nombre"] = nombre
        persona["contrasenia"] = contrasenia
        persona["fecha_nacimiento"] = fecha_nacimiento
        return "Usuario creado, con los datos: <br>"+persona["nombre"]+"<br>"+persona["contrasenia"]+"<br>"+persona["correo"]+""+persona["fecha_nacimiento"]
    else:
        return posible_error

@application.route('/detalles/<nombre>/<usuario>_<contrasenia>')
def get_detalles(nombre, usuario, contrasenia):

    encontrado_a = False
    encontrado_b = False
    usuario_prueba = {
        "Nombre":"Usuario de prueba",
        "Constrasenia":"Contraseña1@",
        "Correo":"ejemplo@correo.es",
        "Fecha_nacimiento":"2000-01-12"
    }


    for item in persona.values():
        # Comprobar que el usuario que se busca existe
        if(item == nombre):
            encontrado_a = True
        # Comprobar que el usuario introducido existe
        if(item == usuario):
            encontrado_b = True
        
    # Si el usuario introducio existe se busca la contraseña
    if encontrado_b:
        for item in persona.values():
            if(item == contrasenia):
                encontrado_b = False
    
    if encontrado_b == False:
        return "El usuario introducido es incorrecto<br>Aquí tienes un usuario de ejemplo:<br>Nombre: "+persona["nombre"]+"<b>Contraseña: "+persona["contrasenia"]+"<br>Correo: "+persona["correo"]+"<br>Fecha de nacimiento: "+persona["fecha_nacimiento"]

    if encontrado_a == False:
        return "El usuario introducido no existe<br>Aquí tienes un usuario de ejemplo:<br>Nombre: "+persona["nombre"]+"<br>Contraseña: "+persona["contrasenia"]+"<br>Correo: "+persona["correo"]+"<br>Fecha de nacimiento: "+persona["fecha_nacimiento"]


def comprobar_contrasenia(passwd):
      
    SpecialSym =['$', '@', '#', '%']
    val = True
    error = ""
      
    if len(passwd) < 6:
        error += '<br>La contraseña debe tener al menos 6 dígitos'
        val = False
          
    if len(passwd) > 20:
        error +='<br>La contraseña no puede tener más de 20 dígitos'
        val = False
          
    if not any(char.isdigit() for char in passwd):
        error +='<br>La contraseña debe tener al menos un número'
        val = False
          
    if not any(char.isupper() for char in passwd):
        error +='<br>La contraseña debe tener al menos una mayúscula'
        val = False
          
    if not any(char.islower() for char in passwd):
        error +='<br>La contraseña debe tener al menos una minúscula'
        val = False
          
    if not any(char in SpecialSym for char in passwd):
        error +='<br>La contraseña debe tener alguno de estos símbolos $@#'
        val = False

    if val:
        return ""
    else:
        return error

def comprobar_correo(correo):
    Caracter = ["@"]
    val = True
    error = ""

    if not any(char in Caracter for char in correo):
        error +='<br>No es un correo válido'
        val = False
    
    if val:
        return ""
    else:
        return error
        
def comprobar_fecha(fecha):

    val = True
    error = ""

    try:
        datetime.strptime(fecha, '%Y-%m-%d')
    except ValueError:
        val = False
        error = "<br>La fecha es incorrecta el formato es AÑO-MES-DÍA"

    if val:
        return ""
    else:
        return error
